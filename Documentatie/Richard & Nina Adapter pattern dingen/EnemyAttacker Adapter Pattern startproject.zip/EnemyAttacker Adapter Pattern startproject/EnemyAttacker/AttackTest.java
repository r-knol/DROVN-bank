package EnemyAttacker;
/*
Adapter pattern: De "wereldstekker".
Een adapter-klasse zorgt ervoor dat input vanuit de Client
(de tank) wordt omgezet in de juiste actie. Een robot slaat,
loopt en reageert op een mens. En een tank schiet, rijdt en
wijst een bestuurder toe; hij kent enkel deze commando's.
*/

public class AttackTest {

    public static void main(String[] args){
        // 1. Maak een Adapter-klasse die gedrag van een tank kan omzetten in gedrag van een robot.
        // TODO: klasse aanmaken

        // 2. Maak een Tank-object aan en laat deze tank gedrag vertonen.
        // TODO: jouw code

        // 3. Maak een Robot-object aan en laat deze robot gedrag vertonen.
        // TODO: jouw code

        // 4. Maak een nieuwe adapter, die de robot uit 3 meekrijgt.
        // TODO: jouw code

        //5. Gebruik deze adapter om de robot gedrag te laten vertonen (met de commando's van de tank :) )
        // TODO: jouw code
    }
}
