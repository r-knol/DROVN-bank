package EnemyAttacker;

/*
De interface beschrijft een protocol die andere klassen moeten
volgen. De client (tank) implement deze interface. Uiteindelijk
is het de adapters taak om nieuwe classes te maken die compatibel
zijn met deze interface (dit protocol).
 */

public interface EnemyAttacker {
    public void fireWeapon();
    public void driveForward();
    public void assignDriver(String driverName);

}
