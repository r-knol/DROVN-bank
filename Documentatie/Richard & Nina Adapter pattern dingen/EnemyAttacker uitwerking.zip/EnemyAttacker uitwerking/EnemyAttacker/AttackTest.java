package EnemyAttacker;
/*
Adapter pattern: De "wereldstekker".
Een adapter-klasse zorgt ervoor dat input vanuit de Client
(de tank) wordt omgezet in de juiste actie. Een robot slaat,
loopt en reageert op een mens. En een tank schiet, rijdt en
wijst een bestuurder toe; hij kent enkel deze commando's.
*/

public class AttackTest {

    public static void main(String[] args){
        // 1. Maak een Adapter-klasse die gedrag van een tank kan omzetten in gedrag van een robot.
        // Zie nieuwe klasse

        // 2. Maak een Tank-object aan en laat deze tank gedrag vertonen.
        Tank fatTank = new Tank();

        System.out.println("The Enemy Tank");
        fatTank.assignDriver("Frank");
        fatTank.driveForward();
        fatTank.fireWeapon();
        System.out.println();

        // 3. Maak een Robot-object aan en laat deze robot gedrag vertonen.
        Robot keesTheRobot = new Robot();

        System.out.println("The Robot");
        keesTheRobot.reactToHuman("Paul");
        keesTheRobot.walkForward();
        keesTheRobot.smashWithHands();
        System.out.println();

        // 4. Maak een nieuwe adapter, die de robot uit 3 meekrijgt.
        TankToRobotAdapter tankToRobotAdapter = new TankToRobotAdapter(keesTheRobot);

        // 5. Gebruik deze adapter om de robot gedrag te laten vertonen (met de commando's van de tank :) )
        System.out.println("The Robot with Adapter");
        tankToRobotAdapter.assignDriver("Mark");
        tankToRobotAdapter.driveForward();
        tankToRobotAdapter.fireWeapon();

    }
}
