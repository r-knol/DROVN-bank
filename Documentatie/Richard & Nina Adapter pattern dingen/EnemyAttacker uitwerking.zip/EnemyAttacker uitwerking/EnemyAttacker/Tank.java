package EnemyAttacker;

/*
Use the Adapter class when you want to use some existing
class, but its interface isn’t compatible with the rest
of your code.
*/

/*
Tank (client) implementeert de EnemyAttacker interface.
Deze klasse is het vertrekpunt met bestaande/initiële
'business logic' van het programma. Nu kun je meerdere klassen
gaan maken (Robot, Animal, etc.), met verschillende methods/
gedragingen. Deze client werkt met de adapter via de client interface.
Hierdoor kun je nieuwe adapters toevoegen zonder de bestaande
client code (van tank) aan te tasten. Dit is handig wanneer de
interface van de service klasse (van robot) wordt vervangen of
wijzigt. Je kunt dan gewoon een nieuwe adapter maken zonder de
client code (tank) aan te tasten.
*/

import java.util.Random;

public class Tank implements EnemyAttacker {

    Random generator = new Random();

    @Override
    public void fireWeapon() {
        int attackDamage = generator.nextInt(10) + 1;
        System.out.println("Enemy Tank Does " + attackDamage + " Damage");
    }

    @Override
    public void driveForward() {
        int movement = generator.nextInt(5) + 1;
        System.out.println("Enemy Tank moves: " + movement + " spaces");
    }

    @Override
    public void assignDriver(String driverName) {
        System.out.println(driverName + " is driving the tank");
    }
}
