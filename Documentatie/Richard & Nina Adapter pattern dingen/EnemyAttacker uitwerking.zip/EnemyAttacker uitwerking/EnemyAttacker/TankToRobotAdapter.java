package EnemyAttacker;

/*
De wereldstekker. Hier regel je dat input vanuit de Client
(de tank) wordt omgezet in de juiste actie. Een robot slaat,
loopt en reageert op een mens. En een tank schiet, rijdt en
wijst een bestuurder toe, terwijl de gebruiker voor iedere
actie slechts 1 commando kent.
*/

public class TankToRobotAdapter implements EnemyAttacker {

    Robot theRobot;

    public TankToRobotAdapter(Robot newRobot){
        theRobot = newRobot;
    }

    public void fireWeapon() {
        theRobot.smashWithHands();
    }

    public void driveForward() {
        theRobot.walkForward();
    }

    public void assignDriver(String driverName) {
        theRobot.reactToHuman(driverName);
    }
}





